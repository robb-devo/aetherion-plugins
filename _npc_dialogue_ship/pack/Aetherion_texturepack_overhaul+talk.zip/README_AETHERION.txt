Aetherion Gear Test v5
======================
Hunter Crossbow: real crossbow shape (tinted vanilla), works in GUI/dev menu/hand.

WORN ARMOR on Fabric:
OptiFine-for-Fabric often does NOT apply armor CIT reliably.
Install Fabric mod: CIT Resewn (for 1.21.1)
  https://modrinth.com/mod/cit-resewn
Then enable this resource pack and press F3+T.

This pack includes CIT in BOTH:
  assets/minecraft/optifine/cit/
  assets/minecraft/citresewn/cit/